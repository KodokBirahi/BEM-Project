# Responsive Bottom Navigation Bar
## [Watch it on youtube]()
### Responsive Bottom Navigation Bar

- Lower navigation bar using HTML, CSS and JavaScript.
- First design with labels in the navigation bar.
- Second design with points in the navigation bar.
- Smooth scrolling in each section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![responsive bottom navigation](/preview.png)
